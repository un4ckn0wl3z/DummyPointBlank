﻿/*
 * Arquivo: SLOT_CHANGE.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 01/08/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.room
{
    public class SLOT_CHANGE
    {
        public SLOT oldSlot, newSlot;
    }
}