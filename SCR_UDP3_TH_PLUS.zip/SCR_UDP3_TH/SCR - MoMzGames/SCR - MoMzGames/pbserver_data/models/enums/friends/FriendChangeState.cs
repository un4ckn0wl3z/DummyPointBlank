﻿namespace Core.models.enums.friends
{
    public enum FriendChangeState
    {
        Insert = 1,
        Accept = 2,
        Delete = 3,
        Update = 4,
    }
}