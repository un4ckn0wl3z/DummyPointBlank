﻿/*
 * Arquivo: ClientLocale.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 03/12/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.enums.global
{
    public enum ClientLocale
    {
        korea = 1,
        Thai = 2,
        Indonesia = 3,
        Russia = 4,
        Turkey = 5,
        China = 6,
        Taiwan = 7,
        Brazil = 9,
        Latin_America = 10,
        NorthAmerica = 11,
        Italy = 12,
        English = 13,
        MiddleEast = 14,
        Philippines = 15
    }   //Default = Dev
}