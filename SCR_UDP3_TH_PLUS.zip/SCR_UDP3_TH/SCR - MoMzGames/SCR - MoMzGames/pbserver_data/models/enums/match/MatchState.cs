﻿/*
 * Arquivo: MatchState.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 20/07/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.enums.match
{
    public enum MatchState
    {
        Invisible,
        Ready,
        Play
    }
}