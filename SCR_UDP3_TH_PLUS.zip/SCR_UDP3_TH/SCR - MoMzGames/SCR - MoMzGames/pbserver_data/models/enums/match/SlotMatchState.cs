﻿/*
 * Arquivo: SlotMatchState.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 17/12/2016
 * Sintam inveja, não nos atinge
 */

namespace Core.models.enums.match
{
    public enum SlotMatchState
    {
        Empty,
        Normal,
        Ready,
        Play
    }
}