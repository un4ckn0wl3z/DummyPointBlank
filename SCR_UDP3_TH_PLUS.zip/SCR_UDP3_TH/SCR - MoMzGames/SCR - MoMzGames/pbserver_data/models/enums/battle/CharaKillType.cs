﻿namespace Core.models.enums.room
{
    public enum CharaKillType
    {
        DEFAULT,
        PIERCING,
        MASS
    }
}