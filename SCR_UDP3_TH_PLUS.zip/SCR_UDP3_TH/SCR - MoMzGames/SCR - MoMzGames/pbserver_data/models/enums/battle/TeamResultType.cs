﻿namespace Core.models.enums
{
    public enum TeamResultType
    {
        TeamRedWin,
        TeamBlueWin,
        TeamDraw
    }
}