﻿/*
 * Arquivo: ITEM_TAG.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 17/12/2016
 * Sintam inveja, não nos atinge
 */

namespace Core.models.enums
{
    public enum ITEM_TAG
    {
        NORMAL,
        NEW,
        HOT,
        EVENT,
        PCCAFE,
        SALE
    }
}