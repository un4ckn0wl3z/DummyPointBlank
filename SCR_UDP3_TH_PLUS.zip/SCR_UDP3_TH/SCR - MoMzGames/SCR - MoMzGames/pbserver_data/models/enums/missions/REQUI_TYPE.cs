﻿namespace Core.models.enums.missions
{
    public enum REQUI_TYPE
    {
        CUMULATIVA = 1,
        NORMAL = 2,
        ROUND_1 = 3
    }
}