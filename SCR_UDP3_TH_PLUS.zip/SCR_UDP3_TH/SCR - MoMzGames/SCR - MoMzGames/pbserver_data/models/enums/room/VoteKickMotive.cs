﻿namespace Core.models.enums.room
{
    public enum VoteKickMotive
    {
        NoManner,
        IllegalProgram,
        Abuse,
        ETC
    }
}