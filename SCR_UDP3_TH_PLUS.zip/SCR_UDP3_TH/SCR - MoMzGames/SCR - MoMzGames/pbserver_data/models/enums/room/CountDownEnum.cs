﻿/*
 * Arquivo: CountDownEnum.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 13/05/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.enums
{
    public enum CountDownEnum
    {
        Start = 5,
        StopByPlayer = 254,
        StopByHost = 255
    }
}