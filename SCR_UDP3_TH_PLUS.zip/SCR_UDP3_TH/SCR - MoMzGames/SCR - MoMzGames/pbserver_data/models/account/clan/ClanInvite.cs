﻿/*
 * Arquivo: ClanInvite.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 19/03/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.account.clan
{
    public class ClanInvite
    {
        public int clan_id, inviteDate;
        public long player_id;
        public string text;
    }
}