﻿using Core.models.account.players;

namespace Core.models.account.mission
{
    public class MissionItemAward
    {
        public int _missionId;
        public ItemsModel item;
    }
}