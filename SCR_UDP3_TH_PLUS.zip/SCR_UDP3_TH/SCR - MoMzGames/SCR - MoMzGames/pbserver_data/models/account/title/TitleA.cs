﻿/*
 * Arquivo: TitleA.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 25/11/2016
 * Sintam inveja, não nos atinge
 */

using Core.models.account.players;

namespace Core.models.account.title
{
    public class TitleA
    {
        public int _id;
        public ItemsModel _item;
    }
}