﻿/*
 * Arquivo: PlayerEquipedItems.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 26/03/2017
 * Sintam inveja, não nos atinge
 */

namespace Core.models.account.players
{
    public class PlayerEquipedItems
    {
        public int _primary, _secondary, _melee, _grenade, _special, _red, _blue, _helmet, _beret, _dino;
    }
}