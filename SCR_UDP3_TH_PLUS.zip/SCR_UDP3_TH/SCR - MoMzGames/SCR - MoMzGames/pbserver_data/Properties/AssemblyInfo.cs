﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Informações gerais sobre um assembly são controladas através do seguinte 
// conjunto de atributos. Altere o valor destes atributos para modificar a informação
// associada a um assembly.
[assembly: AssemblyTitle("PBServer Core")]
[assembly: AssemblyDescription("PointBlank Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MoMz Games")]
[assembly: AssemblyProduct("PBServer")]
[assembly: AssemblyCopyright("Copyright © MoMz Games 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Definir ComVisible como false torna os tipos neste assembly não visíveis 
// para componentes COM.  Caso precise acessar um tipo neste assembly a partir de 
// COM, defina o atributo ComVisible como true nesse tipo.
[assembly: ComVisible(false)]

// O GUID a seguir é para o ID da typelib se este projeto for exposto para COM
[assembly: Guid("a575e011-41cb-45e4-a90f-77ca3a1b61ff")]

// Informações de Versão para um assembly consistem nos quatro valores a seguir:
//
//      Versão Principal
//      Versão Secundária 
//      Número da Versão
//      Revisão
//
// É possível especificar todos os valores ou usar o padrão de Números de Compilação e Revisão 
// utilizando o '*' como mostrado abaixo:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.0.0.1")]
[assembly: AssemblyFileVersion("0.0.3.0")]
[assembly: NeutralResourcesLanguageAttribute("pt-BR")]
