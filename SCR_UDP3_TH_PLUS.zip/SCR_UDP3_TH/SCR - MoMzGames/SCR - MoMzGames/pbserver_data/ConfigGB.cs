﻿using System.Text;

namespace Core
{
    public static class ConfigGB
    {
        public static string dbName, dbHost, dbUser, dbPass;
        public static int dbPort;
        public static Encoding EncodeText;
    }
}