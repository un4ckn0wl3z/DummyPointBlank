﻿using System.Reflection;
using System.Resources;
// Assembly BattleServer, Version 1.0.5014.23792

[assembly: AssemblyTitle("PBServer Battle")]
[assembly: AssemblyDescription("PointBlank Battle")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MoMz Games")]
[assembly: AssemblyProduct("PBServer")]
[assembly: AssemblyCopyright("Copyright © MoMz Games 2018")]
[assembly: AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]

[assembly: AssemblyVersionAttribute("1.0.0.*")]
[assembly: AssemblyFileVersion("2.1.3.0")]
[assembly: NeutralResourcesLanguageAttribute("pt-BR")]