﻿using Battle.data.enums;

namespace Battle.data.models
{
    public class DeathServerData
    {
        public CHARA_DEATH _deathType;
        public Player _player;
    }
}