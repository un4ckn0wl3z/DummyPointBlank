﻿namespace Battle.data.enums
{
    public enum HitType
    {
        Normal,
        HeadshotCritical,
        HeadshotProtection,
        HelmetProtection
    }
}