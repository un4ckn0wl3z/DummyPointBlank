﻿namespace Battle.data.enums.weapon
{
    public enum EQMIPEMENT_SLOT
    {
        PRIM,
        SUB,
        MELEE,
        THROWING,
        ITEM,
        CHAR_RED,
        CHAR_BLUE,
        CHAR_HEAD,
        CHAR_ITEM
    }
}