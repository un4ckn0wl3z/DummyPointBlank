﻿namespace Battle.data.enums
{
    public enum P2P_SUB_HEAD
    {
        USER,
        GRENADE,
        DROPEDWEAPON,
        OBJECT_STATIC,
        OBJECT_MOVE,
        OBJECT_DYNAMIC,
        OBJECT_ANIM,
        NPC,
        STAGEINFO_CHARA,
        STAGEINFO_OBJ_STATIC,
        STAGEINFO_OBJ_MOVE,
        STAGEINFO_OBJ_DYNAMIC,
        STAGEINFO_OBJ_ANIM,
        CONTROLED_OBJECT,
        STAGEINFO_MISSION
    }
}