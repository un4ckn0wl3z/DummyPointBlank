﻿namespace Battle.data.enums
{
    public enum ObjectType
    {
        Nothing,
        User,
        UserObject,
        Object
    }
}