﻿/*
 * Arquivo: BASE_CHATTING_REC.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 07/01/2018
 * Sintam inveja, não nos atinge
 */

using Core;
using Core.models.account.clan;
using Core.models.account.players;
using Core.models.enums;
using Core.models.enums.flags;
using Core.models.enums.global;
using Core.models.enums.match;
using Core.models.room;
using Core.server;
using Game.data.chat;
using Game.data.managers;
using Game.data.model;
using Game.data.utils;
using Game.global.serverpacket;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Game.global.clientpacket
{
    public class BASE_CHATTING_REC : ReceiveGamePacket
    {
        private string text;
        private ChattingType type;
        public BASE_CHATTING_REC(GameClient client, byte[] data)
        {
            makeme(client, data);
        }

        public override void read()
        {
            type = (ChattingType)readH();
            text = readS(readH());
        }
        public override void run()
        {
            try
            {
                Account player = _client._player;
                if (player == null || string.IsNullOrEmpty(text) || text.Length > 60 ||
                    player.player_name.Length == 0)
                    return;


                Room room = player._room;
                SLOT sender;
                switch (type)
                {
                    case ChattingType.Team:
                        if (room == null)
                            return;

                        sender = room._slots[player._slotId];
                        int[] array = room.GetTeamArray(sender._team);
                        using (ROOM_CHATTING_PAK packet = new ROOM_CHATTING_PAK((int)type, sender._id, player.UseChatGM(), text))
                        {
                            byte[] data = packet.GetCompleteBytes("CHAT_NORMAL_REC-1");
                            lock (room._slots)
                                foreach (int slotIdx in array)
                                {
                                    SLOT receiver = room._slots[slotIdx];
                                    Account pR = room.getPlayerBySlot(receiver);
                                    if (pR != null && SlotValidMessage(sender, receiver))
                                        pR.SendCompletePacket(data);
                                }
                        }
                        break;
                    case ChattingType.All:
                    case ChattingType.Lobby:
                        if (room != null)
                        {
                            if (!serverCommands(player, room))
                            {
                                sender = room._slots[player._slotId];
                                using (ROOM_CHATTING_PAK packet = new ROOM_CHATTING_PAK((int)type, sender._id, player.UseChatGM(), text))
                                {
                                    byte[] data = packet.GetCompleteBytes("CHAT_NORMAL_REC-2");
                                    lock (room._slots)
                                        for (int slotIdx = 0; slotIdx < 16; ++slotIdx)
                                        {
                                            SLOT receiver = room._slots[slotIdx];
                                            Account pR = room.getPlayerBySlot(receiver);
                                            if (pR != null && SlotValidMessage(sender, receiver))
                                                pR.SendCompletePacket(data);
                                        }
                                }
                            }
                            else _client.SendPacket(new ROOM_CHATTING_PAK((int)type, player._slotId, true, text));
                        }
                        else
                        {
                            Channel channel = player.getChannel();
                            if (channel == null)
                                return;

                            if (!serverCommands(player, room))
                            {
                                using (LOBBY_CHATTING_PAK packet = new LOBBY_CHATTING_PAK(player, text))
                                    channel.SendPacketToWaitPlayers(packet);
                            }
                            else _client.SendPacket(new LOBBY_CHATTING_PAK(player, text, true));
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.warning(ex.ToString());
            }
        }
        private bool serverCommands(Account player, Room room)
        {
            return true;
        }
        /// <summary>
        /// Checa se os slots são válidos para trocarem mensagens na sala.
        /// </summary>
        /// <param name="sender">Remetente</param>
        /// <param name="receiver">Destinatário</param>
        /// <returns></returns>
        private bool SlotValidMessage(SLOT sender, SLOT receiver)
        {
            return (((int)sender.state == 7 || (int)sender.state == 8) && ((int)receiver.state == 7 || (int)receiver.state == 8) ||
                    ((int)sender.state >= 9 && (int)receiver.state >= 9) && (receiver.specGM ||
                    sender.specGM ||
                    sender._deathState.HasFlag(DeadEnum.useChat) ||
                    sender._deathState.HasFlag(DeadEnum.isDead) && receiver._deathState.HasFlag(DeadEnum.isDead) ||
                    sender.espectador && receiver.espectador ||
                    sender._deathState.HasFlag(DeadEnum.isAlive) && receiver._deathState.HasFlag(DeadEnum.isAlive) && (sender.espectador && receiver.espectador || !sender.espectador && !receiver.espectador)));
        }
    }
}