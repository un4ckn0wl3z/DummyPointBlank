﻿namespace Game.data.model
{
    public class PlayerSession
    {
        public uint _sessionId;
        public long _playerId;
    }
}