﻿/*
 * Arquivo: ClanModel.cs
 * Código criado pela MoMz Games
 * Última data de modificação: 14/07/2016
 * Sintam inveja, não nos atinge
 */

namespace Game.data.utils
{
    public class ClanModel
    {
        public int clanId, RedPlayers, BluePlayers;
    }
}