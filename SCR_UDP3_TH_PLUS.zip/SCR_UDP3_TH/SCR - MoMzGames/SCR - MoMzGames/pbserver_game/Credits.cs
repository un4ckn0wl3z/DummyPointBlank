﻿/* Agradecemos a colaboração e participação, neste projeto, de todas as pessoas listadas abaixo:
 * 
 * FumaPraQue, yGigaSeet
 * Felipe,
 * Alexandre (R4MOS), Matheus (yDeath), Denilson (), Kayan (Yamada), Geovanee (Geová), Guilherme (Pato),
 * Uendel (Unity), Wendel (Infinite), Bruno, Erick, João (Scotti), Emmanuel (), Ricardo (), Johann,
 * Oroch, PROGRAMMATOR, Stallker, Henrique (PISTOLA)
 * Juliano, Angelo (Lokes)
 * 
 * Nenhuma das pessoas cima tem qualquer relação com a Zepetto Inc. ou Ongame Entretenimento.
 * Todos os direitos de publicação desta source devem SEMPRE seguir as regras de publicação do jogo eletrônico,
 * Point Blank, da Zepetto Inc. e da Ongame Entretenimento.
 * Se você tiver acesso a este projeto, recomendamos que você exclua este projeto COMPLETAMENTE, e que NÃO
 * distribua o mesmo para nenhuma pessoa.
 

 By GoogleTranslate -
 * We appreciate the collaboration and participation in this project of all the people listed below:
 *
 * FumaPraQue, and GigaSeet
 * Felipe,
 * Alexandre (R4MOS), Matheus (yDeath), Denilson (), Kayan (Yamada), Geovanee (Geová), Guilherme
 * Uendel (Unity), Wendel (Infinite), Bruno, Erick, John (Scotti), Emmanuel (), Ricardo (), Johann,
 * Oroch, PROGRAMMATOR, (Stallker), Henrique (PISTOL)
 * Juliano, Angelo (Lokes)
 *
 * None of the above people has any relationship with Zepetto Inc. or Ongame Entertainment.
 * All publishing rights of this source must ALWAYS follow the rules of publication of the electronic game,
 * Point Blank, from Zepetto Inc.and Ongame Entertainment.
 * If you have access to this project, we recommend that you delete this project COMPLETELY, and DO NOT
 * Distribute the same to no one.
 
 By GoogleTranslate - 
  * Aşağıda listelenen tüm kişilerin bu projedeki işbirliğini ve katılımını takdir ediyoruz:
  *
  * FumaPraQue ve GigaSeet
  * Felipe
  * Alexandre (R4MOS), Matheus (yDeath), Denilson (), Kayan (Yamada), Geovanee (Geová), Guilherme
  * Uendel(Unity), Wendel (Infinite), Bruno, Erick, John (Scotti), Emmanuel (), Ricardo (), Johann,
  * Oroch, PROGRAMMATOR, (Stallker), Henrique (PISTOL)
  * Juliano, Angelo (Lokes)
  *
  * Yukarıdaki kişilerin hiçbirinin Zepetto Inc. veya Ongame Entertainment ile hiçbir ilişkisi yoktur.
  * Bu kaynağın tüm yayın hakları HERHANGİ elektronik oyunun yayın kurallarına uygun olmalıdır.
  * Zepetto Inc. ve Ongame Entertainment'dan Point Blank.
  * Bu projeye erişiminiz varsa, bu projeyi TAMAMEN silmenizi ve TAMAMLAMAYINIZ
  * Aynı şeyi kimseye dağıtmayın.
  */