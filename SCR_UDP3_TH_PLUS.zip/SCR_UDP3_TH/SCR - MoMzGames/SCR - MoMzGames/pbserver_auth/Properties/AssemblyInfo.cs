﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// Informações gerais sobre um assembly são controladas através do seguinte 
// conjunto de atributos. Altere o valor destes atributos para modificar a informação
// associada a um assembly.
[assembly: AssemblyTitle("PBServer Auth")]
[assembly: AssemblyDescription("PointBlank Auth")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MoMz Games")]
[assembly: AssemblyProduct("PBServer")]
[assembly: AssemblyCopyright("Copyright © MoMz Games 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Definir ComVisible como false torna os tipos neste assembly não visíveis 
// para componentes COM.  Caso precise acessar um tipo neste assembly a partir de 
// COM, defina o atributo ComVisible como true nesse tipo.
[assembly: ComVisible(false)]

// O GUID a seguir é para o ID da typelib se este projeto for exposto para COM
[assembly: Guid("42b9977e-03bd-4cfb-809e-ad224c1fd1d4")]

// Informações de Versão para um assembly consistem nos quatro valores a seguir:
//
//      Versão Principal
//      Versão Secundária 
//      Número da Versão
//      Revisão
//
// É possível especificar todos os valores ou usar o padrão de Números de Compilação e Revisão 
// utilizando o '*' como mostrado abaixo:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("0.0.4.1")]
[assembly: NeutralResourcesLanguageAttribute("pt-BR")]
